$(function(){	//$(document).ready(function()の短縮形
  loadContacts();
  });

function loadContacts(){
	$.getJSON("/Contacts/data", function(data)	//HTTPリクエストを発行し，完了後，下記のコードを実行します。
			  {
			  var contactsList = '';
			  
			  $.each(data, function(index, value){
					 
					 contactsList = contactsList + '<li uid="' + value.contactId + '">';
					 contactsList = contactsList + value.lastName;
					 contactsList = contactsList + value.firstName + '</li>';
					 
					 });
			  
			  $("#contactList").html(contactsList);//このオブジェクトはソースに存在します。
			  
			  })
	return true;
}
