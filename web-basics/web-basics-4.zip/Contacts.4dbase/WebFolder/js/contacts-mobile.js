$(function(){	//$(document).ready(function()の短縮形
  loadContacts();
  });

function loadContacts(){
	$.getJSON("/Contacts/data", function(data)	//HTTPリクエストを発行し，完了後，下記のコードを実行します。
			  {
			  var contactsList = '';
			  
			  $.each(data, function(index, value){
					 
					 contactsList = contactsList + '<li onClick="selectContact(\'' + value.contactId + '\')" uid="' + value.contactId + '">';
					 contactsList = contactsList + '<a href="#contact" data-transition="slide">';
					 contactsList = contactsList + value.lastName;
					 contactsList = contactsList + value.firstName + '</a></li>';					 
					 
					 });
			  
			  $("#contactsListView").html(contactsList);//このオブジェクトはソースに存在します。
			  $("#contactsListView").listview('refresh');//リストの内容を変更したので，jQuery Mobileにリフレッシュを要求する必要があります。
			  
			  })
	return true;
}

//1ページ目の行がタップされたときに実行される関数です。
function selectContact(ContactId){
	$.getJSON('data', 'contactId='+ContactId, function(data){
			  //4Dから返されたJSONからフィールドの値を取り出し，入力エリアに代入します。
			  $("#contactId").val(data.contactId);
			  $("#firstName").val(data.firstName);
			  $("#lastName").val(data.lastName);
			  $("#email").val(data.email);
			  $("#mobilePhone").val(data.mobilePhone);
			  
			  })
	return true;
}

//2ページ目の保存ボタンがタップされたときに実行される関数です。
function saveContact(){
	//ここでPOSTした値は，4DのWEB GET VARIABLESで読み取ることができます。
	$.post('data/update', $("#contactForm").serialize(), function(data){
		   loadContacts();
		   })
}